import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
 public bookDetails:any=[{title:'book 1',author:'author 1',publisher:'publisher 1'},{title:'book 2',author:'author 2',publisher:'publisher 2'},{title:'book 3',author:'author 3',publisher:'publisher 3'}];
 selBook:any;
 addBook(data:any){
this.selBook=data;
 }
 constructor() { }

  ngOnInit() {
  }

}
